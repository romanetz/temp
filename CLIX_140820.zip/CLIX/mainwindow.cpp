#include "mainwindow.h"
#include "ui_mainwindow.h"
//#include "form2.h"
//#include "ui_form2.h"
//#include "aboutclix.h"
//#include "ui_aboutclix.h"
#include "switch.h"
#include "clickablelabel.h"

#include <QSerialPortInfo>

#define PORT_VENDOR 0x0483U
#define PORT_PRODUCT 0x572bU
#define ORGANIZATION_NAME "Elastic labs"
#define APPLICATION_NAME "CLIX"


#include <QLabel>
#include <QMessageBox>
#include <QRegularExpression>
#include <QRegularExpressionMatch>
#include <QDebug>
#include <QSettings>

void MainWindow::parse_payload()
{
bool ok;
int range;

m_re->setPattern("heartbeat(\\d+)");
QRegularExpressionMatch match = m_re->match(parse_string);
if (match.hasMatch()) {
    qDebug()<<parse_string;
    unsigned int  h_n = match.captured(1).toInt(&ok,10);
    if (ok && (qAbs((long int)heartbeat_num-(long int)h_n))<5)
        {
            m_ui->connection_state->setPixmap(*usb_on_pic);
            m_ui->connection_state_2->setPixmap(*usb_on_pic);
            timeout=0;
        }
    else
        {
            m_ui->connection_state->setPixmap(*usb_off_pic);
            m_ui->connection_state_2->setPixmap(*usb_off_pic);
        }
    heartbeat_num = h_n;
}

m_re->setPattern("r(\\d+),(\\d+),(\\d+)");
match = m_re->match(parse_string);
if (match.hasMatch())
    {
        qDebug()<<parse_string;
        QString range_num = match.captured(3);
        QString num_r = match.captured(1);
        range=range_num.toInt(&ok,10);
        int sensor_num=num_r.toInt(&ok,10);
        {switch (sensor_num)
            {
                case 1:
                //m_ui->progressBar_1->setFormat(QString("%1\"").arg(qMin(range/25.4,(double)m_ui->progressBar_1->maximum()/100.0),4,'f',1,0));
                m_ui->progressBar_1->setValue(qMin(range/0.254,(double)m_ui->progressBar_1->maximum()));
                m_ui->progressBar_1->update();
                break;
                case 2:
                //m_ui->progressBar_2->setFormat(QString("%1\"").arg(qMin(range/25.4,(double)m_ui->progressBar_2->maximum()/100.0),4,'f',1,0));
                m_ui->progressBar_2->setValue(qMin(range/0.254,(double)m_ui->progressBar_2->maximum()));
                m_ui->progressBar_2->update();
                break;
                case 3:
                //m_ui->progressBar_3->setFormat(QString("%1\"").arg(qMin(range/25.4,(double)m_ui->progressBar_3->maximum()/100.0),4,'f',1,0));
                m_ui->progressBar_3->setValue(qMin(range/0.254,(double)m_ui->progressBar_3->maximum()));
                m_ui->progressBar_3->update();
                break;
                case 4:
                //m_ui->progressBar_4->setFormat(QString("%1\"").arg(qMin(range/25.4,(double)m_ui->progressBar_4->maximum()/100.0),4,'f',1,0));
                m_ui->progressBar_4->setValue(qMin(range/0.254,(double)m_ui->progressBar_4->maximum()));
                m_ui->progressBar_4->update();
                break;
            }
        QString time_st = match.captured(2);
        }
    }

m_re->setPattern("s(\\d+)Start");
match = m_re->match(parse_string);
if (match.hasMatch())
    {
        qDebug()<<parse_string;
        QString num_r = match.captured(1);
        int sensor_num=num_r.toInt(&ok,10);
        if(ok)
        {switch (sensor_num)
            {
                case 1: lifts_count++; update_calories(); break;
            }
            m_ui->num_total->setText(QString::number(lifts_count));
            m_ui->num_total_2->setText(QString::number(lifts_count));
        }
    }

m_re->setPattern("s(\\d+)End");
match = m_re->match(parse_string);
if (match.hasMatch())
{
    qDebug()<<parse_string;
    QString num_r = match.captured(1);
    int sensor_num=num_r.toInt(&ok,10);
    if(ok)
    {
        ;
    }
    }

}


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , m_ui(new Ui::MainWindow),
      m_serial(new QSerialPort(this)),
      m_re(new QRegularExpression("*")),
      usb_off_pic(new QPixmap(":/pix/images/usb_off.png")),
      usb_on_pic(new QPixmap(":/pix/images/usb_on.png"))
{
   /*commands.insert("LMB","Left mouse button");
   commands.insert("RMB","right mouse button"),
   commands.insert("MMB","middle mouse button"),
   commands.insert("ENK","enter key"),
   commands.insert("SPB","spacebar"),
   commands.insert("PRD","period"),
   commands.insert("CMA","comma"),
   commands.insert("SFT","shift key"),
   commands.insert("NON","none");

   modes.insert("pr","press & release");
   modes.insert("ph","press & hold");
*/



    new_day=QDateTime::fromString(QString("03:00:00"),"hh:mm:ss");
    //m_form2 =new Form2(nullptr,app_settings);
    //m_aboutclix = new aboutclix(nullptr);

    //![1]
    series = new QLineSeries();
    QDateTime dateMin, dateMax;
    //![1]

    //![2]
    stats = new(QFile);
#if defined (Q_OS_MACOS)
    stats->setFileName("/Users/Shared/clixstats.txt");
#else
    stats->setFileName("clixstats.txt");
#endif
    if (!stats->open(QIODevice::ReadWrite)) {
        QMessageBox::critical(this, tr("Error when opening statistics"), stats->errorString());
    }
    else
    {
        //fill the graph with statistics
        stream=new QTextStream(stats);
        QDateTime momentInTime;
        while (!stream->atEnd()) {
            QString line = stream->readLine();
            if (line.startsWith("#") || line.startsWith(":"))
                continue;
            QStringList values = line.split(" ", QString::SkipEmptyParts);
            if (values.size()==3)
            {momentInTime=QDateTime::fromString(values[0]+" "+values[1],"yyyy-MM-dd hh:mm:ss");
                        //QDate(values[0].toInt(), values[1].toInt() , 15));
            double y=values[2].toDouble();
            if (y>=0.0)
                series->append(momentInTime.toMSecsSinceEpoch(), y);
            }
        }
    }

    //![2]

    //![3]
    stats_chart = new QChart();
    stats_chart->addSeries(series);
    stats_chart->legend()->hide();
    //stats_chart->setTitle("");
    //![3]

    //![4]
    QDateTimeAxis *axisX = new QDateTimeAxis;
    axisX->setTickCount(10);
    axisX->setFormat("dd MMM yyyy");
    axisX->setTitleText("Date");
    stats_chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);
    dateMin=axisX->min();
    dateMax=axisX->max();
    //get current
    last_data_timestamp=dateMax;
    QDateTime time = QDateTime::currentDateTime();
    if ((time.toSecsSinceEpoch()-last_data_timestamp.toSecsSinceEpoch())>86400)
        {
        lifts_count=0;
        person.calories=0.0;
        };


    QValueAxis *axisY = new QValueAxis;
    axisY->setLabelFormat("%i");
    axisY->setTitleText("Lifts");
    stats_chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);
    //![4]


    m_ui->setupUi(this);
    m_ui->btnApplyTrigger->setEnabled(false);

    m_ui->comboBox_units->addItem(QString("lbs"),MainWindow::lbs);
    m_ui->comboBox_units->addItem(QString("kg"),MainWindow::kg);


    m_ui->comboBox_resistance->addItem(QString("none"),double(0));
    m_ui->comboBox_resistance->addItem(QString("2,5 lbs"),double(2.5));
    m_ui->comboBox_resistance->addItem(QString("5 lbs"),double(5));
    m_ui->comboBox_resistance->addItem(QString("7,5 lbs"),double(7.5));
    m_ui->comboBox_resistance->addItem(QString("10 lbs"),double(10));
    m_ui->comboBox_resistance->addItem(QString("12,5 lbs"),double(12.5));
    m_ui->comboBox_resistance->addItem(QString("15 lbs"),double(15));
    m_ui->comboBox_resistance->addItem(QString("17,5 lbs"),double(17.5));
    m_ui->comboBox_resistance->addItem(QString("20 lbs"),double(20));

    //number+key
    m_ui->comboBox_key->addItem(QString("left mouse button"),QString("LMB"));
    m_ui->comboBox_key->addItem(QString("right mouse button"),QString("RMB"));
    m_ui->comboBox_key->addItem(QString("middle mouse button"),QString("MMB"));
    m_ui->comboBox_key->addItem(QString("enter key"),QString("ENK"));
    m_ui->comboBox_key->addItem(QString("space bar"),QString("SPB"));
    m_ui->comboBox_key->addItem(QString("period"),QString("PRD"));
    m_ui->comboBox_key->addItem(QString("comma"),QString("CMA"));
    m_ui->comboBox_key->addItem(QString("shift"),QString("SFT"));
    m_ui->comboBox_key->addItem(QString("none"),QString("NON"));

    //number+pr or ph
    m_ui->comboBox_mode->addItem(QString("press & release"),QString("pr"));
    m_ui->comboBox_mode->addItem(QString("press & hold"),QString("ph"));

    saved_settings=new QSettings (QSettings::IniFormat,QSettings::UserScope,"Elastic labs","CLIX");
    saved_settings->beginGroup( "General" );
    //app_settings.gender = qvariant_cast<MainWindow::genders>(saved_settings->value( "gender",MainWindow::male ));
    app_settings.weight = saved_settings->value( "weight", 200 ).toInt();
    app_settings.weight_unit = qvariant_cast<MainWindow::weight_units>(saved_settings->value( "weight_unit", MainWindow::lbs ));
    app_settings.resistance = saved_settings->value( "resistance",(double)0.0 ).toDouble();
    app_settings.calories = saved_settings->value( "calories",(double)0.0 ).toDouble();
    app_settings.margin = saved_settings->value( "margin", 50 ).toInt();

    app_settings.leftkey = saved_settings->value( "leftkey", QString("NON")).toString();
    app_settings.leftmode = saved_settings->value( "leftmode", QString("pr")).toString();
    //app_settings.rightkey = saved_settings->value( "rightkey", QString("NON")).toString();
    //app_settings.rightmode = saved_settings->value( "rightmode", QString("pr")).toString();
    app_settings.trigger_1 = saved_settings->value("trigger_1", app_settings.trigger_1).toDouble();
    app_settings.release_1 = app_settings.trigger_1+app_settings.margin;//saved_settings->value("release_1", app_settings.release_1).toDouble();

    saved_settings->endGroup();
    m_ui->spinBox_weight->setValue(app_settings.weight);
    m_ui->doubleSpinBox_trig->setValue(app_settings.trigger_1/25.4);
    m_ui->comboBox_resistance->setCurrentIndex(m_ui->comboBox_resistance->findData(app_settings.resistance));
    m_ui->comboBox_units->setCurrentIndex(m_ui->comboBox_units->findData(app_settings.weight_unit));

    //m_ui->resetCounters->setStyleSheet( "*{border-image: url(:/pix/images/reset_small.png);}"
    //":pressed{ border-image: url(:/pix/images/reset_small_pressed.png);}");

    m_ui->dateEnd->setMaximumDate(dateMax.date());
    m_ui->dateEnd->setMinimumDate(dateMin.date());
    m_ui->dateBegin->setMaximumDate(dateMax.date());
    m_ui->dateBegin->setMinimumDate(dateMin.date());
    m_ui->dateEnd->setDate(m_ui->dateEnd->maximumDate());
    m_ui->dateBegin->setDate(m_ui->dateBegin->minimumDate());

    //![5]
    m_ui->graphicsView->setChart(stats_chart);
    m_ui->graphicsView->setRenderHint(QPainter::Antialiasing);
    //![5]

    m_ui->Button_home->setChecked(true);
    m_ui->gridStackedWidget->setCurrentIndex(0);


    //connecting signals to slots
    connect(m_serial, &QSerialPort::errorOccurred, this, &MainWindow::handleError);
    connect(m_serial, &QSerialPort::readyRead, this, &MainWindow::readData);
    connect(m_ui->m_switch, &Switch::switch_changed, this,  &MainWindow::send_switch);
    connect(m_ui->labelSitting, &ClickableLabel::clicked, this, &MainWindow::labelSittingClicked);
    connect(m_ui->labelStanding, &ClickableLabel::clicked, this, &MainWindow::labelStandingClicked);

    QImage* l_slider_img=new QImage(":/pix/images/Arrow_r.png");
    QImage* u_slider_img=new QImage(":/pix/images/Arrow_t.png");

    range_slider_1=new RangeSlider(l_slider_img,u_slider_img,Qt::Horizontal, RangeSlider::Option::DoubleHandles);
    range_slider_1->SetRange(0,(int)(36*25.4));
    range_slider_1->setEnabled(true);
    range_slider_1->SetLowerValue(app_settings.trigger_1);
    range_slider_1->SetUpperValue(app_settings.release_1);
    QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Expanding);
    sizePolicy2.setHorizontalStretch(0);
    sizePolicy2.setVerticalStretch(0);
    sizePolicy2.setHeightForWidth(range_slider_1->sizePolicy().hasHeightForWidth());
    range_slider_1->setSizePolicy(sizePolicy2);
    range_slider_1->setMinimumSize(QSize(420,50));
    range_slider_1->setMaximumSize(QSize(16777215, 16777215));

    //range_slider_main->setAlignment(Qt::AlignCenter);
    m_ui->gridLayout_6->addWidget(range_slider_1,6,2,1,3);

    connect(range_slider_1,&RangeSlider::lowerValueChanged,this,&MainWindow::update_lower); //lower->updatetrig
    connect(range_slider_1,&RangeSlider::upperValueChanged,this,&MainWindow::update_upper); //upper-updaterelease

    m_ui->Button_home->setAutoRaise(true);
    m_ui->Button_gear->setAutoRaise(true);
    m_ui->Button_graph->setAutoRaise(true);
    m_ui->Button_help->setAutoRaise(true);
    openSerialPort();
    labelSittingClicked();

    m_filedlg=new QFileDialog(this,Qt::Dialog);

    main_timer = new QTimer(this);
    connect(main_timer, &QTimer::timeout, this,&MainWindow::checkTime);
    main_timer->start(1000);
    //connect(m_form2, &QWidget::setHidden, this, &MainWindow::sendSettings);

    person.weight=app_settings.weight;
    person.weight_unit=app_settings.weight_unit;
    person.resistance=app_settings.resistance;
    person.calories=app_settings.calories;
    update_calories();
}

MainWindow::~MainWindow()
{
    //delete m_form2;
    delete m_ui;
}

void MainWindow::checkTime()
{
update_stats();
if (!m_serial->isOpen())
    openSerialPort();
if (timeout<3)
    timeout++;
else if (m_serial->isOpen())
    {m_ui->connection_state->setPixmap(*usb_off_pic);
    m_ui->connection_state_2->setPixmap(*usb_off_pic);
    closeSerialPort();
    }

}

void MainWindow::update_stats(bool update_now)
{
    //get current
    QDateTime timestamp_ = QDateTime::currentDateTime();
    qint64 t=timestamp_.toSecsSinceEpoch();
    //more than one day after last storing
    if ((t-last_data_timestamp.toSecsSinceEpoch())>86400 || \
            (t-last_data_timestamp.date().addDays(1).startOfDay().toSecsSinceEpoch()>10800) || update_now)
    {
        QString line = timestamp_.toString("yyyy-MM-dd hh:mm:ss")+" "+QString::number(lifts_count)+"\n";
        //stats->seek(-1);
        stats->write(line.toLatin1());
        last_data_timestamp=timestamp_;
        series->append(timestamp_.toSecsSinceEpoch(),(double)(lifts_count));
        QDateTime dateMax=static_cast<QDateTimeAxis*>(series->attachedAxes()[0])->max();
        m_ui->dateEnd->setMaximumDate(dateMax.date());
        m_ui->dateBegin->setMaximumDate(dateMax.date());
        m_ui->dateEnd->setDate(m_ui->dateEnd->maximumDate());
        lifts_count=0;
        update_calories();
    }
}

void MainWindow::openSerialPort()
{
    QString description;
    QString manufacturer;
    QString serialNumber;
    QString portname="";
    uint16_t vendor;
    uint16_t product;
    const auto infos = QSerialPortInfo::availablePorts();

    for (const QSerialPortInfo &info : infos) {
        vendor=info.vendorIdentifier();
        product=info.productIdentifier();
         if ((vendor == PORT_VENDOR) &&
             (product== PORT_PRODUCT))
            {
             qCritical() << "Found device with SN" << info.serialNumber();
             portname=info.portName();
             break;}
        }
    if (portname!="")
    {
        m_serial->setPortName(portname);
        m_serial->setBaudRate(QSerialPort::Baud115200);
        m_serial->setDataBits(QSerialPort::Data8);
        m_serial->setParity(QSerialPort::NoParity);
        m_serial->setStopBits(QSerialPort::OneStop);
        m_serial->setFlowControl(QSerialPort::NoFlowControl);
        if (m_serial->open(QIODevice::ReadWrite))
        {
           // QMessageBox::information(this, tr("OK"), portname+" connected");

            /*showStatusMessage(tr("Connected to %1 : %2, %3, %4, %5, %6")
                          .arg(p.name).arg(p.stringBaudRate).arg(p.stringDataBits)
                          .arg(p.stringParity).arg(p.stringStopBits).arg(p.stringFlowControl));
*/
            update_arrows();
            update_tl(app_settings.trigger_1,1);
            update_th(app_settings.release_1,1);
            update_key(app_settings.leftkey);
            update_key(app_settings.rightkey);
            update_key(app_settings.leftmode);
            update_key(app_settings.rightmode);
            if (m_switch!=nullptr)
                send_switch(m_ui->m_switch->getState());
                //send_switch(m_switch->getState());


        } else
        {
            qCritical() << m_serial->errorString();
        //QMessageBox::critical(this, tr("Error"), m_serial->errorString());
        //showStatusMessage(tr("Open error"));
        }
    }
    timeout=0;
}
//! [4]

//! [5]
void MainWindow::closeSerialPort()
{
    if (m_serial->isOpen())
        m_serial->close();
    //m_console->setEnabled(false);
    //m_ui->actionConnect->setEnabled(true);
    //m_ui->actionDisconnect->setEnabled(false);
    //m_ui->actionConfigure->setEnabled(true);
    //showStatusMessage(tr("Disconnected"));
    m_ui->connection_state->setPixmap(QPixmap(":/pix/images/usb_off.png"));
    timeout=6;
}
//! [5]

void MainWindow::about()
{
    QMessageBox::about(this, tr("About CLIX"),
                       tr("The <b>CLIX</b> application interfaces with CLIX device"));
}

//! [6]
void MainWindow::writeData(const QByteArray &data)
{
    m_serial->write(data);
}
//! [6]

//! [7]
void MainWindow::readData()
{
    int i=0;
    int last_position=0;
    const QByteArray data = m_serial->readAll();
    do
    {
        i=data.indexOf("\n",last_position);
        if (i>-1)
            {
                parse_string.append(data.mid(last_position,i-last_position));
                parse_payload();
                parse_string.clear();
                last_position=i+1;
            }
        else break;
    }
    while(1);
}
//! [7]


//! [8]
void MainWindow::handleError(QSerialPort::SerialPortError error)
{
    if (error != QSerialPort::NoError) {
        QMessageBox::critical(this, tr("Critical Error"), m_serial->errorString());
        m_serial->clearError();
        closeSerialPort();
    }
}
//! [8]

void MainWindow::on_Button_options_pressed()
{
        //m_form2->setVisible(true);
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
 //   if (m_ui!=nullptr)
 //       QRect line_rect(m_ui->gridLayout_6->itemAtPosition(3,1)
    update_arrows();
    event->accept();
}

void MainWindow::closeEvent(QCloseEvent *event)
{
 //   if (m_ui!=nullptr)
 //       QRect line_rect(m_ui->gridLayout_6->itemAtPosition(3,1)
    update_stats(true);
    update_settings();
    stats->flush();
    stats->close();
}



void MainWindow::update_settings()
{
    //app_settings=data;
    app_settings.weight=person.weight;
    app_settings.resistance=person.resistance;
    app_settings.weight_unit=person.weight_unit;
    app_settings.calories=person.calories;
    saved_settings->beginGroup( "General" );
    saved_settings->setValue( "calories", app_settings.calories );
    saved_settings->setValue( "weight", app_settings.weight );
    saved_settings->setValue( "weight_unit", app_settings.weight_unit );
    saved_settings->setValue( "resistance", app_settings.resistance );
    saved_settings->setValue( "margin", app_settings.margin );
    saved_settings->setValue( "leftkey", app_settings.leftkey);
    saved_settings->setValue( "leftmode", app_settings.leftmode);
    saved_settings->setValue( "trigger_1", app_settings.trigger_1);
    saved_settings->setValue( "release_1", app_settings.release_1);
    saved_settings->endGroup();
    saved_settings->sync();
    update_arrows();
    update_tl(app_settings.trigger_1,1);
    update_th(app_settings.release_1,1);

    update_key(app_settings.leftkey);
    update_key(app_settings.leftmode);
}

void MainWindow::update_arrows()
{
    if (range_slider_1!=nullptr)
     {
         range_slider_1->SetLowerValue(app_settings.trigger_1);
         range_slider_1->SetUpperValue(app_settings.release_1);
     }

    //m_ui->arrow_r->setGeometry((app_settings.release/2000.0)*m_ui->line->width()+(m_ui->line->x())-(m_ui->arrow_r->width())/2,m_ui->arrow_r->y(),m_ui->arrow_r->width(),m_ui->arrow_r->height());
    //m_ui->arrow_t->setGeometry((app_settings.trigger/2000.0)*m_ui->line->width()+(m_ui->line->x())-(m_ui->arrow_t->width())/2,m_ui->arrow_t->y(),m_ui->arrow_t->width(),m_ui->arrow_t->height());
}

void MainWindow::on_Button_gear_toggled(bool checked)
{
    if (checked)
    {
    m_ui->Button_home->setChecked(false);
    m_ui->Button_graph->setChecked(false);
    m_ui->Button_help->setChecked(false);
    m_ui->gridStackedWidget->setCurrentIndex(2);
    }
    else
    {
    if (!m_ui->Button_home->isChecked() && !m_ui->Button_graph->isChecked() && !m_ui->Button_gear->isChecked() && !m_ui->Button_help->isChecked() )   m_ui->Button_home->setChecked(true);
    }
}

void MainWindow::update_calories()
{
    switch(person.person_pose)
    {
    case sitting:
        person.calories=lifts_count*(0.000165 * person.weight*(person.weight_unit==MainWindow::weight_units::kg?2.20462:1.0000) + 0.004*person.resistance);break;
    case standing:
        person.calories=lifts_count*(0.000365 * person.weight*(person.weight_unit==MainWindow::weight_units::kg?2.20462:1.0000) + 0.004*person.resistance);break;
    default: break;
    }
    m_ui->num_calories->setText(QString("%1").arg(person.calories,8,'d',1,0));
    m_ui->num_calories_2->setText(QString("%1").arg(person.calories,8,'d',1,0));

}

void MainWindow::on_Button_home_toggled(bool checked)
{
    if (checked)
    {
    m_ui->Button_gear->setChecked(false);
    m_ui->Button_graph->setChecked(false);
    m_ui->Button_help->setChecked(false);
    m_ui->gridStackedWidget->setCurrentIndex(0);
    }
    else
    {
    if (!m_ui->Button_home->isChecked() && !m_ui->Button_graph->isChecked() && !m_ui->Button_gear->isChecked() && !m_ui->Button_help->isChecked() )   m_ui->Button_home->setChecked(true);
    }
}

void MainWindow::on_Button_graph_toggled(bool checked)
{
    if (checked)
    {
    m_ui->Button_home->setChecked(false);
    m_ui->Button_gear->setChecked(false);
    m_ui->Button_help->setChecked(false);
    m_ui->gridStackedWidget->setCurrentIndex(1);
    }
    else
    {
    if (!m_ui->Button_home->isChecked() && !m_ui->Button_graph->isChecked() && !m_ui->Button_gear->isChecked() && !m_ui->Button_help->isChecked() )   m_ui->Button_home->setChecked(true);
    }
}

void MainWindow::on_Button_help_toggled(bool checked)
{
    if (checked)
    {
    m_ui->Button_home->setChecked(false);
    m_ui->Button_gear->setChecked(false);
    m_ui->Button_graph->setChecked(false);
    m_ui->gridStackedWidget->setCurrentIndex(3);
    }
    else
    {
    if (!m_ui->Button_home->isChecked() && !m_ui->Button_graph->isChecked() && !m_ui->Button_gear->isChecked() && !m_ui->Button_help->isChecked() )   m_ui->Button_home->setChecked(true);
    }
}


void MainWindow::update_tl(double tl,int sensor_index)
{
    QString msg("stl"+QString::number(sensor_index)+QString(",")+QString::number((int)tl)+"\n");
    qDebug() << msg;
    writeData(msg.toLatin1());
};
void MainWindow::update_th(double th,int sensor_index)
{
    QString msg("sth"+QString::number(sensor_index)+QString(",")+QString::number((int)th)+"\n");
    qDebug() << msg;
    writeData(msg.toLatin1());
};

void MainWindow::update_key(QString command)
{
    QString msg("key"+command+"\n");
    qDebug() << msg;
    writeData(msg.toLatin1());
}

void MainWindow::on_Button_about_clicked()
{
    //m_aboutclix->setVisible(true);
}

void MainWindow::on_Button_graph_triggered(QAction *arg1)
{

}

void MainWindow::on_dateBegin_editingFinished()
{
    //(stats_chart->series())[0]->attachedAxes()[0]->setMin(m_ui->dateBegin->date());
    //series->attachAxis(axisX);
}

void MainWindow::on_dateEnd_editingFinished()
{
    //(stats_chart->series())[0]->attachedAxes()[0]->setMax(m_ui->dateEnd->date());
}

void MainWindow::on_dateBegin_dateChanged(const QDate &date)
{

}

void MainWindow::on_dateEnd_dateChanged(const QDate &date)
{

}

void MainWindow::on_dateBegin_userDateChanged(const QDate &date)
{
    ((stats_chart->series())[0]->attachedAxes())[0]->setMin(m_ui->dateBegin->date());
}

void MainWindow::on_dateEnd_userDateChanged(const QDate &date)
{
    ((stats_chart->series())[0]->attachedAxes())[0]->setMax(m_ui->dateEnd->date());
}

void MainWindow::send_switch(bool switch_state)
{
    QString msg("hid_"+(switch_state?QString("on"):QString("off"))+"\n");
    qDebug() << msg;
    writeData(msg.toLatin1());
}


void MainWindow::on_resetCounters_clicked()
{
    lifts_count=0;
    m_ui->num_total->setText(QString::number(lifts_count));
    m_ui->num_total_2->setText(QString::number(lifts_count));
    person.calories=0.0;
}

void MainWindow::update_lower(int aValue)
{
    RangeSlider* t = qobject_cast<RangeSlider*>(sender());
    int z=qMin(aValue+app_settings.margin,t->GetMaximun());
    if (z>t->GetUpperValue())
        {
        t->setUpperValue(qMin(aValue+app_settings.margin,t->GetMaximun()));
        }
    if (t==range_slider_1)
    {
    app_settings.trigger_1=aValue;
    update_tl(app_settings.trigger_1,1);
    m_ui->doubleSpinBox_trig->setValue(aValue/25.4);
    }
}

void MainWindow::update_upper(int aValue)
{
    RangeSlider* t = qobject_cast<RangeSlider*>(sender());
    int z=qMax(aValue-app_settings.margin,t->GetMinimun());
    if (z<t->GetLowerValue())
        {
        t->setLowerValue(qMax(aValue-app_settings.margin,t->GetMinimun()));
        }
    if (t==range_slider_1)
        {
            app_settings.release_1=aValue;
            update_th(app_settings.release_1,1);
        }
}

void MainWindow::labelSittingClicked()
{

m_ui->labelSitting->setFrameShape(QFrame::Box);
m_ui->labelStanding->setFrameShape(QFrame::NoFrame);
m_ui->labelSitting->setStyleSheet(QStringLiteral(
    "QFrame{border:1px solid; border-radius:4px 4px 4px 4px; border-color:rgb(170,225,40);}"));
m_ui->labelStanding->setStyleSheet(QStringLiteral(
    "QFrame{border:none;}"));
person.person_pose=sitting;
update_calories();
//m_ui->comboBox_key->setCurrentIndex(m_ui->comboBox_key->findData(app_settings.leftkey.mid(1)));
//m_ui->comboBox_mode->setCurrentIndex(m_ui->comboBox_mode->findData(app_settings.leftmode.mid(1)));
}

void MainWindow::labelStandingClicked()
{
m_ui->labelStanding->setFrameShape(QFrame::Box);
m_ui->labelSitting->setFrameShape(QFrame::NoFrame);
m_ui->labelStanding->setStyleSheet(QStringLiteral(
    "QFrame{border:1px solid; border-radius:4px 4px 4px 4px; border-color:rgb(170,225,40);}"));
m_ui->labelSitting->setStyleSheet(QStringLiteral(
    "QFrame{border:none;}"));
person.person_pose=standing;
update_calories();
//m_ui->comboBox_key->setCurrentIndex(m_ui->comboBox_key->findData(app_settings.rightkey.mid(1))); //app_settings=1LMB, 2RMB
//m_ui->comboBox_mode->setCurrentIndex(m_ui->comboBox_mode->findData(app_settings.rightmode.mid(1)));
}

void MainWindow::on_pushButton_save_clicked()
{
    update_settings();
}

void MainWindow::on_comboBox_key_currentIndexChanged(int index)
{
    (void)index;
    app_settings.leftkey=QString("1")+qvariant_cast<QString>(m_ui->comboBox_key->currentData());
    update_key(app_settings.leftkey);
    /*switch(active_sensor)
    {
        case 1:

            break;

        case 2:
            app_settings.rightkey=QString::number(active_sensor)+qvariant_cast<QString>(m_ui->comboBox_key->currentData());
            update_key(app_settings.rightkey);
            break;
    }
    */
}

void MainWindow::on_comboBox_mode_currentIndexChanged(int index)
{
    (void)index;
    app_settings.leftmode=QString("1")+qvariant_cast<QString>(m_ui->comboBox_mode->currentData());
    update_key(app_settings.leftmode);
    /*
    switch(active_sensor)
    {
        case 1:

            break;

        case 2:
            app_settings.rightmode=QString::number(active_sensor)+qvariant_cast<QString>(m_ui->comboBox_mode->currentData());
            update_key(app_settings.rightmode);
            break;
    }
    */
}

void MainWindow::on_filenameSelect_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this,
        tr("Load firmware file"), "",
        tr("Raw firmware (*.bin);;All Files (*)"));

    if (m_helper->preProcessImageFile(fileName))
    {
        m_ui->firmwareFileName->setText(fileName);
        m_ui->btnBurn->setEnabled(true);
        m_ui->progressBar_Burn->setEnabled(true);
    }
}

void MainWindow::on_pushButton_updfrm_clicked()
{
    if (!ensureElevated()) {
                qDebug() << "Insufficient privileges";
            return;
        }
    else
    {
        if (m_helper==nullptr)
        {m_helper=new Helper();
        connect(m_helper,&Helper::progressChanged,this,&MainWindow::update_progress);
        }
    }
    m_ui->gridStackedWidget->setCurrentIndex(4);
    m_ui->devicesList->clear();
    m_ui->devicesList->addItems(m_helper->devices());

    m_ui->devicesList->setCurrentIndex(0);
}

void MainWindow::on_btnBurn_clicked()
{
    quint64 image_size=m_helper->getImageSize();
    int dev_index=m_ui->devicesList->currentIndex();
    quint64 device_size=m_helper->getSelectedDeviceSize(m_ui->devicesList->currentIndex());

    if (device_size>=image_size)
    {
    m_helper->writeToDevice(dev_index);
    m_ui->progressBar_Burn->setValue(0);
    m_ui->progressBar_Burn->setMaximum(m_helper->maximumProgressValue());
    }
    else
    {
        QMessageBox::information(this, tr("No contacts in file"),
            tr("Image size is more than selected device size. Check if correct device is selected"));
    }

}

void MainWindow::update_progress()
{
    m_ui->progressBar_Burn->setValue(m_helper->progress());
}

void MainWindow::on_comboBox_units_currentIndexChanged(int index)
{
    (void)index;
    person.weight_unit=qvariant_cast<MainWindow::weight_units>(m_ui->comboBox_units->currentData());
    update_calories();
    //person.weight_mult=qvariant_cast<double>(m_ui->comboBox_units->currentData());
}

void MainWindow::on_comboBox_resistance_currentIndexChanged(int index)
{
    (void)index;
    person.resistance=qvariant_cast<double>(m_ui->comboBox_resistance->currentData());
    update_calories();
}

void MainWindow::on_spinBox_weight_editingFinished()
{
    person.weight=static_cast<unsigned int>(m_ui->spinBox_weight->value());
    update_calories();
}

/*void MainWindow::on_comboBox_gender_currentIndexChanged(int index)
{
    person.gender=qvariant_cast<MainWindow::genders>(m_ui->comboBox_gender->currentData());
}
*/

void MainWindow::on_debugLog_stateChanged(int arg1)
{
    if (arg1)
            qInstallMessageHandler(myMessageOutput);
    else
         qInstallMessageHandler(0);
}

void MainWindow::on_doubleSpinBox_trig_valueChanged(double arg1)
{
    if (fabs(app_settings.trigger_1 - arg1*25.4)>0.0001)
        m_ui->btnApplyTrigger->setEnabled(true);
    // double arg1=m_ui->doubleSpinBox_trig->value()*25.4;
    /*    app_settings.trigger_1 = arg1*25.4;
        app_settings.release_1 = arg1*25.4+app_settings.margin;
        update_arrows();
        update_tl(app_settings.trigger_1,1);
        update_th(app_settings.release_1,1);
        */
}

void MainWindow::on_doubleSpinBox_trig_editingFinished()
{
    double arg1=m_ui->doubleSpinBox_trig->value()*25.4;
    if (fabs(app_settings.trigger_1 - arg1)>0.0001)
        m_ui->btnApplyTrigger->setEnabled(true);
}

void MainWindow::on_btnApplyTrigger_clicked()
{
    double arg1=m_ui->doubleSpinBox_trig->value()*25.4;
    app_settings.trigger_1 = arg1;
    app_settings.release_1 = arg1+app_settings.margin;
    update_arrows();
    update_tl(app_settings.trigger_1,1);
    update_th(app_settings.release_1,1);
    //m_ui->btnApplyTrigger->setDisabled(false);
    m_ui->btnApplyTrigger->setEnabled(false);
}

void MainWindow::on_switchMode_clicked()
{
    QString msg("boot\n");
    qDebug() << msg;
    writeData(msg.toLatin1());
}
