#include "advancedprogressbar.h"

AdvancedProgressBar::AdvancedProgressBar(QWidget* parent) : QProgressBar(parent)
{

}
