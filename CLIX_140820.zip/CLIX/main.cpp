  #include "helper.h"
#if defined(Q_OS_LINUX)
#include "src/signalhandler.h"
#include <signal.h>
#endif
#include "framelesswindow.h"
#include "mainwindow.h"
#include <QApplication>
#include <QStyleFactory>
#include <QTranslator>
#include <QLocale>
#include <QIcon>
#include <QDebug>

#include <stdio.h>
#include <stdlib.h>

// Smart pointer to log file
QScopedPointer<QFile>   m_logFile;

// The implementation of the handler
void myMessageOutput(QtMsgType type, const QMessageLogContext &context, const QString &msg)
{
    QByteArray localMsg = msg.toLocal8Bit();
    const char *file = context.file ? context.file : "";
    const char *function = context.function ? context.function : "";
    QTextStream ts(m_logFile.data());
    // Write the date of recording
    ts << QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz; ");
    switch (type) {
    case QtDebugMsg:
        //ts<<QString("Debug; %1; (%2:%3, %4)\n").arg(QString(localMsg.constData()),QString(file),QString::number(context.line),QString(function));
        ts<<QString("Debug; %1\n").arg(QString(localMsg.constData()));
        break;
    case QtInfoMsg:
        //ts<<QString("Info: %1 (%2:%3, %4)\n").arg(QString(localMsg.constData()),QString(file),QString::number(context.line),QString(function));
        ts<<QString("Info; %1\n").arg(QString(localMsg.constData()));
        break;
    case QtWarningMsg:
        ts<<QString("Warning; %1; %2; %3; %4\n").arg(QString(localMsg.constData()),QString(file),QString::number(context.line),QString(function));
        //ts<<QString("Warning; %1\n").arg(QString(localMsg.constData()));
        break;
    case QtCriticalMsg:
        ts<<QString("Critical; %1; %2; %3; %4\n").arg(QString(localMsg.constData()),QString(file),QString::number(context.line),QString(function));
        //ts<<QString("Critical; %1\n").arg(QString(localMsg.constData()));
        break;
    case QtFatalMsg:
        ts<<QString("Fatal; %1; %2; %3; %4\n").arg(QString(localMsg.constData()),QString(file),QString::number(context.line),QString(function));
        //ts<<QString("Fatal; %1\n").arg(QString(localMsg.constData()));
        break;
    }
}

int main(int argc, char *argv[])
{

    // Set the logging file
    // check which a path to file you use

    // Set the logging file
    // check which a path to file you use
    m_logFile.reset(new QFile("messagelog.csv"));
    // Open the file logging
    m_logFile->open(QFile::Append | QFile::Text);

    QApplication::setDesktopSettingsAware(false);
#if (QT_VERSION >= QT_VERSION_CHECK(5, 6, 0))
    QApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif


    QApplication a(argc, argv);


#if defined(Q_OS_LINUX)
    setup_unix_signal_handlers();
#endif


    QTranslator t;
        if (t.load(":/translations/piw_" + QLocale::system().name())) {
            a.installTranslator(&t);
        } else {
            qDebug() << "Could not load the translation";
        }

#if defined(Q_OS_WIN32)
    // CoInitialize() seems to be called by Qt automatically, so only set security attributes
    HRESULT res = CoInitializeSecurity(NULL, -1, NULL, NULL, RPC_C_AUTHN_LEVEL_PKT, RPC_C_IMP_LEVEL_IMPERSONATE, NULL, EOAC_NONE, 0);
    if (res != S_OK)
    {
        qDebug() << "CoInitializeSecurity failed! (Code: 0x%08lx)\n", res;
        return res;
    }
#endif
    qApp->setStyle(QStyleFactory::create("Fusion"));
    // Create the palette for dark style
    QPalette darkPalette;

    // Set the palette for colour roles of interface items
    darkPalette.setColor(QPalette::Window, QColor(53, 53, 53));
    darkPalette.setColor(QPalette::WindowText, Qt::white);
    darkPalette.setColor(QPalette::Base, QColor(25, 25, 25));
    darkPalette.setColor(QPalette::AlternateBase, QColor(53, 53, 53));
    darkPalette.setColor(QPalette::ToolTipBase, Qt::white);
    darkPalette.setColor(QPalette::ToolTipText, Qt::white);
    darkPalette.setColor(QPalette::Text, Qt::white);
    darkPalette.setColor(QPalette::Button, QColor(53, 53, 53));
    darkPalette.setColor(QPalette::ButtonText, Qt::white);
    darkPalette.setColor(QPalette::BrightText, Qt::red);
    darkPalette.setColor(QPalette::Link, QColor(170, 225, 40));
    darkPalette.setColor(QPalette::Highlight, QColor(170, 225, 40));
    darkPalette.setColor(QPalette::HighlightedText, Qt::black);

    // Set the palette
    qApp->setPalette(darkPalette);

    // loadstylesheet
    /*
    QFile qfDarkstyle(QStringLiteral("://images/darkstyle.qss"));
    if (qfDarkstyle.open(QIODevice::ReadOnly | QIODevice::Text)) {
      // set stylesheet
      QString qsStylesheet = QString::fromLatin1(qfDarkstyle.readAll());
      qApp->setStyleSheet(qsStylesheet);
      qfDarkstyle.close();
    }
*/

    FramelessWindow framelessWindow;
    //framelessWindow.setWindowState(Qt::WindowFullScreen);
    //framelessWindow.setWindowTitle("test title");
    framelessWindow.setWindowIcon(a.style()->standardIcon(QStyle::SP_DesktopIcon));
    MainWindow w;

    w.setWindowFlags(Qt::FramelessWindowHint);
    QApplication::setWindowIcon(QIcon(":/pix/images/mainlabel.png"));
    // add the mainwindow to our custom frameless window
    framelessWindow.setContent(&w);



    // create frameless window (and set windowState or title)

    framelessWindow.show();

    return a.exec();
}
