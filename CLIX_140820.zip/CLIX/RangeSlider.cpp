
#include "RangeSlider.h"
#include <QDebug>
#include <QLabel>
#include <QPointF>
#include <QtGlobal>
#include <QFontMetrics>

namespace
{

const int scHandleSideLength = 16; //was 11
const int scSliderBarHeight = 5;// was 5
const int scLeftRightMargin = 13;

}

RangeSlider::RangeSlider(QWidget* aParent)
    : QWidget(aParent),
      mMinimum(0),
      mMaximum(100),
      mLowerValue(0),
      mUpperValue(100),
      mFirstHandlePressed(false),
      mSecondHandlePressed(false),
      mInterval(mMaximum - mMinimum),
      mBackgroudColorEnabled(QColor(0x1E, 0x90, 0xFF)),
      mBackgroudColorDisabled(Qt::darkGray),
      mBackgroudColor(mBackgroudColorEnabled),
      orientation(Qt::Horizontal)
{
    setMouseTracking(true);
    QLabel *mLowerHandlerLabel = new QLabel(aParent);
    QLabel *mLowerHandlerLabelText = new QLabel(aParent);
    mLowerHandlerLabelText->setText("T");
    QLabel *mUpperHandlerLabel = new QLabel(aParent);
    QLabel *mUpperHandlerLabelText = new QLabel(aParent);
    mUpperHandlerLabelText->setText("R");

}

RangeSlider::RangeSlider(Qt::Orientation ori, Options t, QWidget* aParent)
    : QWidget(aParent),
      mMinimum(0),
      mMaximum(100),
      mLowerValue(0),
      mUpperValue(100),
      mFirstHandlePressed(false),
      mSecondHandlePressed(false),
      mInterval(mMaximum - mMinimum),
      mBackgroudColorEnabled(QColor(0x1E, 0x90, 0xFF)),
      mBackgroudColorDisabled(Qt::darkGray),
      mBackgroudColor(mBackgroudColorEnabled),
      orientation(ori),
      type(t)
{
    setMouseTracking(true);
    QLabel *mLowerHandlerLabel = new QLabel(this);
    QLabel *mLowerHandlerLabelText = new QLabel(this);
    mLowerHandlerLabelText->setText("T");
    mLowerHandlerLabelText->setFont(QFont("Myriad Pro",14,QFont::Normal));
    QLabel *mUpperHandlerLabel = new QLabel(this);
    QLabel *mUpperHandlerLabelText = new QLabel(this);
    mUpperHandlerLabelText->setFont(QFont("Myriad Pro",14,QFont::Normal));
    mUpperHandlerLabelText->setText("R");
}


RangeSlider::RangeSlider(  QImage* lowerImg, QImage* upperImg, Qt::Orientation ori, Options t, bool h, QWidget* aParent)
    : QWidget(aParent),
    mHandlesEnabled(h),
    mMinimum(0),
    mMaximum(100),
    mLowerValue(0),
    mUpperValue(100),
    mFirstHandlePressed(false),
    mSecondHandlePressed(false),
    mInterval(mMaximum - mMinimum),
    mBackgroudColorEnabled(QColor(170, 225, 40)),
    mBackgroudColorDisabled(Qt::darkGray),
    mBackgroudColor(mBackgroudColorEnabled),
    orientation(ori),
    type(t),
    lowerSliderImg(*lowerImg),
    upperSliderImg(*upperImg)
{
    setMouseTracking(true);
    lowerSliderPixmap=QPixmap::fromImage(lowerSliderImg);
    upperSliderPixmap=QPixmap::fromImage(upperSliderImg);
    mLowerHandlerLabel = new QLabel(this);
    mLowerHandlerLabel->setPixmap(lowerSliderPixmap);
    mLowerHandlerLabelText = new QLabel(this);
    mLowerHandlerLabelText->setText("T");
    mLowerHandlerLabelText->setFont(QFont("Myriad Pro",14,QFont::Normal));
    mUpperHandlerLabel = new QLabel(this);
    mUpperHandlerLabel->setPixmap(upperSliderPixmap);
    mUpperHandlerLabelText = new QLabel(this);
    mUpperHandlerLabelText->setText("R");
    mUpperHandlerLabelText->setFont(QFont("Myriad Pro",14,QFont::Normal));
    if (!lowerSliderPixmap.isNull())
        mLowerHandlerLabel->setGeometry(0,0,lowerSliderPixmap.width(),lowerSliderPixmap.height());
    if (!upperSliderPixmap.isNull())
        mUpperHandlerLabel->setGeometry(0,0,upperSliderPixmap.width(),upperSliderPixmap.height());
    this->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);
}



void RangeSlider::paintEvent(QPaintEvent* aEvent)
{
    Q_UNUSED(aEvent);
    QPainter painter(this);

    // Background
    QLine backgroundLine;
    //QRect backgroundRect;
    if(orientation == Qt::Horizontal)
        backgroundLine.setPoints(QPoint(scLeftRightMargin,0),QPoint(width()-scLeftRightMargin,0));
        //backgroundRect = QRectF(scLeftRightMargin, (height() - scSliderBarHeight) / 2, width() - scLeftRightMargin * 2, scSliderBarHeight);
    else
        ; //backgroundRect = QRectF((width() - scSliderBarHeight) / 2, scLeftRightMargin, scSliderBarHeight, height() - scLeftRightMargin*2);

    QPen pen(Qt::gray, 0.8);
    painter.setPen(pen);
    painter.setRenderHint(QPainter::Antialiasing);
    QBrush backgroundBrush(QColor(0xD0, 0xD0, 0xD0));
    painter.setBrush(backgroundBrush);
    painter.drawLine(backgroundLine);
    //painter.drawRoundedRect(backgroundRect, 1, 1);

    // First value handle rect
    QRectF leftHandleRect = firstHandleRect();
    // Second value handle rect
    QRectF rightHandleRect = secondHandleRect();

    float percentageL = (mLowerValue - mMinimum) * 1.0 / mInterval;
    float percentageH = (mUpperValue - mMinimum) * 1.0 / mInterval;
    //x,y,w,h

    QRect LowerLabelSize=QFontMetrics(mLowerHandlerLabelText->font()).tightBoundingRect(mLowerHandlerLabelText->text());
    QRect UpperLabelSize=QFontMetrics(mUpperHandlerLabelText->font()).tightBoundingRect(mUpperHandlerLabelText->text());
    //text coordinates
    int xL = qMax((int)(percentageL * validLength() - LowerLabelSize.width()/2+scLeftRightMargin),0);
    int xH = qMin((int)(percentageH * validLength() - UpperLabelSize.width()/2+scLeftRightMargin),(this->width()-UpperLabelSize.width()));

    if (xH<(xL+LowerLabelSize.width()))
        {
            int shiftL=-(xH-LowerLabelSize.width()-xL)/2;
            //int shiftR
            if (xH+UpperLabelSize.width()==this->width()) shiftL*=2;
            xL=qMax(xL-shiftL,0);
            xH=qMin(xL+LowerLabelSize.width(),this->width()-UpperLabelSize.width());
        }

    LowerLabelSize.moveTo(xL, mLowerHandlerLabel->height()+3); //position from the start
    UpperLabelSize.moveTo(xH, mUpperHandlerLabel->height()+3); //position from the start

    if(type.testFlag(LeftHandle) && mLowerHandlerLabel!=nullptr)
        {
        mLowerHandlerLabel->setGeometry(leftHandleRect.toRect());
        if (!mLowerHandlerLabel->isVisible())
                mLowerHandlerLabel->show();
        mLowerHandlerLabelText->setGeometry(LowerLabelSize);
        }

    if(type.testFlag(RightHandle) && mUpperHandlerLabel!=nullptr)
        {
        mUpperHandlerLabel->setGeometry(rightHandleRect.toRect());
        if (!mUpperHandlerLabel->isVisible())
            mUpperHandlerLabel->show();
        mUpperHandlerLabelText->setGeometry(UpperLabelSize);
        }

    // Handles
    painter.setRenderHint(QPainter::Antialiasing, false);
    QLineF selectedLine(backgroundLine);
    if(orientation == Qt::Horizontal) {
        //selectedLine.setP1((type.testFlag(LeftHandle) ? leftHandleRect.right() : leftHandleRect.left()) + 0.5);
        //selectedLine.setP2((type.testFlag(RightHandle) ? rightHandleRect.left() : rightHandleRect.right()) - 0.5);
    } else {
        //selectedLine.setTop((type.testFlag(LeftHandle) ? leftHandleRect.bottom() : leftHandleRect.top()) + 0.5);
        //selectedLine.setBottom((type.testFlag(RightHandle) ? rightHandleRect.top() : rightHandleRect.bottom()) - 0.5);
    }
    QBrush selectedBrush(mBackgroudColor);
    painter.setBrush(selectedBrush);
    painter.drawLine(selectedLine);
}

QRectF RangeSlider::firstHandleRect() const
{
    float percentage = (mLowerValue - mMinimum) * 1.0 / mInterval;
    //x,y,w,h
    return QRect (percentage * validLength() - lowerSliderPixmap.width()/2+scLeftRightMargin, 3,lowerSliderPixmap.width(),lowerSliderPixmap.height()); //position from the beginning
}

QRectF RangeSlider::secondHandleRect() const
{
    float percentage = (mUpperValue - mMinimum) * 1.0 / mInterval;
    //x,y,w,h
    return QRect (percentage * validLength() - upperSliderPixmap.width()/2+scLeftRightMargin, 3,  upperSliderPixmap.width(),upperSliderPixmap.height());
    //return handleRect(percentage * validLength() + scLeftRightMargin + (type.testFlag(LeftHandle) ? scHandleSideLength : 0));
}


QRectF RangeSlider::handleRect(int aValue) const
{
    if(orientation == Qt::Horizontal)
        return QRect(aValue, (height()-scHandleSideLength) / 2, -1, -1);
    else
        return QRect((width()-scHandleSideLength) / 2, aValue, scHandleSideLength, scHandleSideLength);
}

void RangeSlider::mousePressEvent(QMouseEvent* aEvent)
{
    if(aEvent->buttons() & Qt::LeftButton && mHandlesEnabled)
    {
        int posCheck, posMax, posValue, firstHandleRectPosValue, secondHandleRectPosValue;
        posCheck = (orientation == Qt::Horizontal) ? aEvent->pos().y() : aEvent->pos().x();
        posMax = (orientation == Qt::Horizontal) ? height() : width();
        posValue = (orientation == Qt::Horizontal) ? aEvent->pos().x() : aEvent->pos().y();
        firstHandleRectPosValue = (orientation == Qt::Horizontal) ? firstHandleRect().x()+lowerSliderPixmap.width()/2 : firstHandleRect().y();
        secondHandleRectPosValue = (orientation == Qt::Horizontal) ? secondHandleRect().x()+upperSliderPixmap.width()/2 : secondHandleRect().y();

        mSecondHandlePressed = secondHandleRect().contains(aEvent->pos());
        //qDebug() << "mSecondHandlePressed=" << mSecondHandlePressed;
        mFirstHandlePressed = !mSecondHandlePressed && firstHandleRect().contains(aEvent->pos());
        //qDebug() << "mFirstHandlePressed=" << mFirstHandlePressed;
        if(mFirstHandlePressed)
        {
            mDelta = posValue - firstHandleRectPosValue;
        }
        else if(mSecondHandlePressed)
        {
            mDelta = posValue - secondHandleRectPosValue;
        }
        //qDebug() << "mDelta=" << mDelta;
        if(posCheck >= 2 && posCheck <= posMax - 2)
        {
            int step = mInterval / 10 < 1 ? 1 : mInterval / 10;
            if(posValue < firstHandleRectPosValue)
                setLowerValue(mLowerValue - step);
            else if(((posValue > firstHandleRectPosValue + scHandleSideLength) || !type.testFlag(LeftHandle))
                    && ((posValue < secondHandleRectPosValue) || !type.testFlag(RightHandle)))
            {
                if(type.testFlag(DoubleHandles))
                    if(posValue - (firstHandleRectPosValue + scHandleSideLength) <
                            (secondHandleRectPosValue - (firstHandleRectPosValue + scHandleSideLength)) / 2)
                        setLowerValue((mLowerValue + step < mUpperValue) ? mLowerValue + step : mUpperValue);
                    else
                        setUpperValue((mUpperValue - step > mLowerValue) ? mUpperValue - step : mLowerValue);
                else if(type.testFlag(LeftHandle))
                    setLowerValue((mLowerValue + step < mUpperValue) ? mLowerValue + step : mUpperValue);
                else if(type.testFlag(RightHandle))
                    setUpperValue((mUpperValue - step > mLowerValue) ? mUpperValue - step : mLowerValue);
            }
            else if(posValue > secondHandleRectPosValue + scHandleSideLength)
                setUpperValue(mUpperValue + step);
        }
    }
}

void RangeSlider::mouseMoveEvent(QMouseEvent* aEvent)
{
    if(aEvent->buttons() & Qt::LeftButton)
    {
        int posValue, firstHandleRectPosValue, secondHandleRectPosValue;
        posValue = (orientation == Qt::Horizontal) ? aEvent->pos().x() : aEvent->pos().y();
        firstHandleRectPosValue = (orientation == Qt::Horizontal) ? firstHandleRect().x() : firstHandleRect().y();
        secondHandleRectPosValue = (orientation == Qt::Horizontal) ? secondHandleRect().x() : secondHandleRect().y();

        if(mFirstHandlePressed && type.testFlag(LeftHandle))
        {
            if(posValue - mDelta + scHandleSideLength / 2 <= secondHandleRectPosValue)
            {
                int a = (posValue - mDelta - scLeftRightMargin) * 1.0 / validLength() * mInterval + mMinimum;
                setLowerValue(a);
            }
            else
            {
                setLowerValue(mUpperValue);
            }
        }
        else if(mSecondHandlePressed && type.testFlag(RightHandle))
        {
            if(firstHandleRectPosValue + scHandleSideLength * (type.testFlag(DoubleHandles) ? 1.5 : 0.5) <= posValue - mDelta)
            {
                int a = (posValue - mDelta - scLeftRightMargin) * 1.0 / validLength() * mInterval + mMinimum;
                setUpperValue(a);
            }
            else
            {
                setUpperValue(mLowerValue);
            }
        }
    }
}

void RangeSlider::mouseReleaseEvent(QMouseEvent* aEvent)
{
    Q_UNUSED(aEvent);

    mFirstHandlePressed = false;
    mSecondHandlePressed = false;
}

void RangeSlider::changeEvent(QEvent* aEvent)
{
    if(aEvent->type() == QEvent::EnabledChange)
    {
        if(isEnabled())
        {
            mBackgroudColor = mBackgroudColorEnabled;
        }
        else
        {
            mBackgroudColor = mBackgroudColorDisabled;
        }
        update();
    }
}

QSize RangeSlider::minimumSizeHint() const
{
    return QSize(scHandleSideLength * 2 + scLeftRightMargin * 2, scHandleSideLength);
}

int RangeSlider::GetMinimun() const
{
    return mMinimum;
}

void RangeSlider::SetMinimum(int aMinimum)
{
    setMinimum(aMinimum);
}

int RangeSlider::GetMaximun() const
{
    return mMaximum;
}

void RangeSlider::SetMaximum(int aMaximum)
{
    setMaximum(aMaximum);
}

int RangeSlider::GetLowerValue() const
{
    return mLowerValue;
}

void RangeSlider::SetLowerValue(int aLowerValue)
{
    setLowerValue(aLowerValue);
}

int RangeSlider::GetUpperValue() const
{
    return mUpperValue;
}

void RangeSlider::SetUpperValue(int aUpperValue)
{
    setUpperValue(aUpperValue);
}

void RangeSlider::setLowerValue(int aLowerValue)
{
    if(aLowerValue > mMaximum)
    {
        aLowerValue = mMaximum;
    }

    if(aLowerValue < mMinimum)
    {
        aLowerValue = mMinimum;
    }

    mLowerValue = aLowerValue;
    emit lowerValueChanged(mLowerValue);

    update();
}

void RangeSlider::setUpperValue(int aUpperValue)
{
    if(aUpperValue > mMaximum)
    {
        aUpperValue = mMaximum;
    }

    if(aUpperValue < mMinimum)
    {
        aUpperValue = mMinimum;
    }

    mUpperValue = aUpperValue;
    emit upperValueChanged(mUpperValue);

    update();
}

void RangeSlider::setMinimum(int aMinimum)
{
    if(aMinimum <= mMaximum)
    {
        mMinimum = aMinimum;
    }
    else
    {
        int oldMax = mMaximum;
        mMinimum = oldMax;
        mMaximum = aMinimum;
    }
    mInterval = mMaximum - mMinimum;
    update();

    setLowerValue(mMinimum);
    setUpperValue(mMaximum);

    emit rangeChanged(mMinimum, mMaximum);
}

void RangeSlider::setMaximum(int aMaximum)
{
    if(aMaximum >= mMinimum)
    {
        mMaximum = aMaximum;
    }
    else
    {
        int oldMin = mMinimum;
        mMaximum = oldMin;
        mMinimum = aMaximum;
    }
    mInterval = mMaximum - mMinimum;
    update();

    setLowerValue(mMinimum);
    setUpperValue(mMaximum);

    emit rangeChanged(mMinimum, mMaximum);
}

int RangeSlider::validLength() const
{
    int len = (orientation == Qt::Horizontal) ? width() : height();
    return len - scLeftRightMargin * 2;// - scHandleSideLength * (type.testFlag(DoubleHandles) ? 2 : 1);
}

void RangeSlider::SetRange(int aMinimum, int mMaximum)
{
    setMinimum(aMinimum);
    setMaximum(mMaximum);
}

void RangeSlider::SetHandles(bool enable)
{
    mHandlesEnabled = enable;
}
