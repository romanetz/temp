#include "switch.h"

Switch::Switch(QWidget *parent) : QAbstractButton(parent),
_switch(false),
_opacity(0.000),
_height(45),
_margin(3),
_thumb("#d5d5d5"),
label_height(15),
_anim(new QPropertyAnimation(this, "offset", this))
{
    setOffset((_height-label_height)*0.1);
    //_y = _height / 2+label_height;
    setBrush(QColor("#9F9F9F"));
}

Switch::Switch(const QBrush &brush, QWidget *parent) : QAbstractButton(parent),
_switch(false),
_opacity(0.000),
_height(45),
_margin(3),
_thumb("#d5d5d5"),
label_height(15),
_anim(new QPropertyAnimation(this, "offset", this))
{
    setOffset((_height-label_height)*0.1);
    //_y = (_height-10)/2+10;
    setBrush(brush);
    //QAbstractButton::setCheckable(true);
}

void Switch::paintEvent(QPaintEvent *e) {
    QPainter p(this);
    p.setPen(Qt::NoPen);

    /*if (_switch)
    p.drawText(QPointF(width()-15,0),"ON");
    else
    p.drawText(QPointF(width()-15,0),"OFF");    */
    if (isEnabled()) {
        p.setRenderHint(QPainter::Antialiasing, true);
        p.setBrush(Qt::SolidPattern);
        p.setBrush(_switch ? QColor("#AAE128") : QColor("#808080"));
        p.setPen(QPen(Qt::white));
        p.setOpacity(1.0);
        p.setFont(QFont("Myriad Pro",10,QFont::Bold));
        p.drawText(QPointF(width()/2-8,label_height-2),_switch ? "ON": "OFF");
        p.setPen(QPen(_switch ? QColor("#AAE128") : QColor("#808080"),1,Qt::SolidLine));
        p.drawRoundedRect(QRect(0, label_height, width(), _height-label_height), (_height-label_height)/2.0, (_height-label_height)/2.0);
        p.setBrush(QColor("#F3F3F3"));
        p.drawEllipse(QRectF(offset(), (_height-label_height)*0.1+label_height, (_height-label_height)*0.8,(_height-label_height)*0.8));
    } else {
        p.setRenderHint(QPainter::Antialiasing, true);
        p.setPen(Qt::SolidLine);
        p.setPen(QPen(Qt::darkGray,2));
        p.drawText(QPointF(width()/2-5,8),_switch ? "ON": "OFF");
        p.setOpacity(0.12);
        p.drawRoundedRect(QRect(0, label_height, width(), height()-label_height), (height()-label_height)/2.0, (height()-label_height)/2.0);
        p.setOpacity(1.0);
        p.drawEllipse(QRectF(offset(), (_height-label_height)*0.1, _height*0.7,_height*0.7));
    }

}

void Switch::mouseReleaseEvent(QMouseEvent *e) {
    if (e->button() & Qt::LeftButton) {
        _switch = _switch ? false : true;
        _thumb = _switch ? _brush : QBrush("#d5d5d5");
        if (_switch) {
            _anim->setStartValue((_height-label_height)*0.1);
            _anim->setEndValue(width() - (_height-label_height)*0.9);
            _anim->setDuration(120);
            _anim->start();
        } else {
            _anim->setStartValue(width() - (_height-label_height)*0.9);
            _anim->setEndValue((_height-label_height)*0.1);
            _anim->setDuration(120);
            _anim->start();
        }
    }
    emit switch_changed(_switch);
    QAbstractButton::mouseReleaseEvent(e);
}

void Switch::enterEvent(QEvent *e) {
    setCursor(Qt::PointingHandCursor);
    QAbstractButton::enterEvent(e);
}

QSize Switch::sizeHint() const {
    return QSize(1.5 * (_height + _margin), _height);
}

bool Switch::getState(void)
{
    return _switch;
}
