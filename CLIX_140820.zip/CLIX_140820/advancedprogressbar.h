#ifndef ADVANCEDPROGRESSBAR_H
#define ADVANCEDPROGRESSBAR_H

#include <QProgressBar>

class AdvancedProgressBar: public QProgressBar
{
    Q_OBJECT
public:
    explicit AdvancedProgressBar( QWidget* parent=nullptr );
};



#endif // ADVANCEDPROGRESSBAR_H
