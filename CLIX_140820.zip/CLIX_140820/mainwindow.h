#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPort>
#include <QProgressBar>
#include <QWidget>
#include <QSettings>
#include "common.h"
#include "helper.h"

//#include "calibrate.h"
//#include "advanced.h"
//#include "aboutclix.h"
#include <QtCharts/QChartGlobal>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QChart>
#include <QtCharts/QValueAxis>
#include <QDateTime>
#include "RangeSlider.h"
//#include "windowdragger.h"
#include "switch.h"

QT_BEGIN_NAMESPACE

class QLabel;



namespace Ui { class MainWindow;
             }
QT_END_NAMESPACE

QT_CHARTS_USE_NAMESPACE

class aboutclix;

class Form2;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    enum genders
    {
        male=0,
        female=1,
        other=2
    };
    Q_ENUM(genders)

    enum weight_units
    {
        kg=0,
        lbs=1
    };
    Q_ENUM(weight_units)

    enum training_pose
    {
        sitting=0,
        standing=1
    };
    Q_ENUM(training_pose)

    struct person_type
    {
        MainWindow::weight_units weight_unit;
        double resistance;
        double weight;
        double calories;
        MainWindow::training_pose person_pose;
        //MainWindow::genders gender;
    };

    struct CLIX_Settings{
        //MainWindow::genders gender;
        unsigned int weight;
        MainWindow::weight_units weight_unit;
        double resistance;
        double calories;
        int margin;
        QString leftkey;
        QString leftmode;
        QString rightkey;
        QString rightmode;
        double trigger_1;
        double release_1;
        //QString change_
    };


private slots:
    void openSerialPort();
    void closeSerialPort();
    void about();
    void send_switch(bool switch_state);
    void readData();

    void handleError(QSerialPort::SerialPortError error);

    void on_Button_options_pressed();

    void on_Button_gear_toggled(bool checked);

    void on_Button_home_toggled(bool checked);

    void on_Button_graph_toggled(bool checked);

    void on_Button_about_clicked();

    void on_Button_graph_triggered(QAction *arg1);

    void on_dateBegin_editingFinished();

    void on_dateEnd_editingFinished();

    void on_dateBegin_dateChanged(const QDate &date);

    void on_dateEnd_dateChanged(const QDate &date);

    void on_dateBegin_userDateChanged(const QDate &date);

    void on_dateEnd_userDateChanged(const QDate &date);

    void on_resetCounters_clicked();

    void update_lower(int aValue);
    void update_upper(int aValue);
    void update_calories();
    void on_Button_help_toggled(bool checked);

    void labelSittingClicked();

    void labelStandingClicked();
    void on_pushButton_save_clicked();

    void on_comboBox_key_currentIndexChanged(int index);

    void on_comboBox_mode_currentIndexChanged(int index);

    void on_filenameSelect_clicked();

    void on_pushButton_updfrm_clicked();

    void on_btnBurn_clicked();

    void update_progress();

    void on_comboBox_units_currentIndexChanged(int index);

    void on_comboBox_resistance_currentIndexChanged(int index);

    void on_spinBox_weight_editingFinished();

   // void on_comboBox_gender_currentIndexChanged(int index);

    void on_debugLog_stateChanged(int arg1);

    void on_doubleSpinBox_trig_valueChanged(double arg1);

    void on_doubleSpinBox_trig_editingFinished();

    void on_btnApplyTrigger_clicked();

    void on_switchMode_clicked();

private:
    void initActionsConnections();
protected:
    void closeEvent(QCloseEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;
private:
    //void showStatusMessage(const QString &message);
    void writeData(const QByteArray &data);
    void parse_payload();
    void checkTime();
    void update_tl(double tl,int sensor_index);
    void update_th(double th,int sensor_index);
    void update_key(QString command);
    void update_arrows();
    void update_stats(bool update_now = false);
    void update_settings();
    //int sensor1;
    //int sensor2;
    QString parse_string;
    bool active_string=false;
    bool first_run=true;
    bool init_done=false;
    uint16_t heartbeat;
    int lifts_count=0;
    Ui::MainWindow *m_ui = nullptr;
    //QLabel *m_status = nullptr;
    //Console *m_console = nullptr;
    //Form2 *m_form2 = nullptr;
    //aboutclix *m_aboutclix = nullptr;
    QSerialPort *m_serial = nullptr;
    QRegularExpression *m_re = nullptr;
    QSettings *saved_settings = nullptr;
    CLIX_Settings app_settings;
    QFile *stats= nullptr;
    QTextStream *stream= nullptr;
    QChart *stats_chart= nullptr;
    QTimer *main_timer= nullptr;
    QDateTime new_day,last_data_timestamp;
    QLineSeries *series= nullptr;
    RangeSlider *range_slider_1= nullptr;
    Switch* m_switch= nullptr;
    QPixmap* usb_off_pic= nullptr;
    QPixmap* usb_on_pic= nullptr;
    Helper* m_helper = nullptr;
    QFileDialog* m_filedlg = nullptr;
    unsigned int heartbeat_num;
    int timeout=0;
    person_type person;
    };
#endif // MAINWINDOW_H
