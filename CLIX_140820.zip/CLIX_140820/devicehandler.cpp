#include "devicehandler.h"

DeviceHandler::DeviceHandler(QObject *parent) : QObject(parent)
{

}
